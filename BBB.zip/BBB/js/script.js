// ハンバーガーメニュー
jQuery(function ($) { 
  $('.hamburger').on('click', function() {
    if ($('header').hasClass('active')) {
      $('header').removeClass('active');
    } else {
      $('header').addClass('active');
    }
  });
  // リンクをクリックした時にメニューを閉じる
  $('.navi a').on('click', function() {
    $('header').removeClass('active');
  });
}); 

// Inview（画面に表示されたタイミングで処理を実行）
jQuery(function ($) { 
  $('.inview-slide-left').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
    if(isInView){
      // 要素が表示されたらslide-leftクラスを追加
      $(this).stop().addClass('slide-left');
   }
  });
  // BBBが選ばれる理由（スライド右）
  $('.inview-slide-right').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
    if(isInView){
      // 要素が表示されたらslide-rightクラスを追加
      $(this).stop().addClass('slide-right');
    }
  });
  // 受講生の声（ふきだし）
  $('.inview-balloon').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
    if(isInView){
      // 要素が表示されたらballoonクラスを追加
      $(this).stop().addClass('balloon');
    }
  });
});